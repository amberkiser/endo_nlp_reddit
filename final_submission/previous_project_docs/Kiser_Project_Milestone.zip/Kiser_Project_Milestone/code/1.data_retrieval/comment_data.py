from psaw import PushshiftAPI
import pandas as pd
import numpy as np
from retrieve_data import CommentData


api = PushshiftAPI()

# endo_sub = CommentData(api, 'Endo')
# endo_sub.retrieve_comments(limit=10000)
# endo_sub.comments_to_dataframe()
# endo_sub.clean_comment_data()
# endo_sub.save_comment_data()

# endometriosis_sub = CommentData(api, 'endometriosis')
# endometriosis_sub.retrieve_comments(limit=10000)
# endometriosis_sub.comments_to_dataframe()
# endometriosis_sub.clean_comment_data()
# endometriosis_sub.save_comment_data()

# twox_sub = CommentData(api, 'TwoXChromosomes')
# twox_sub.retrieve_comments(limit=10000)
# twox_sub.comments_to_dataframe()
# twox_sub.clean_comment_data()
# twox_sub.save_comment_data()

# chronicpain_sub = CommentData(api, 'ChronicPain')
# chronicpain_sub.retrieve_comments(limit=10000)
# chronicpain_sub.comments_to_dataframe()
# chronicpain_sub.clean_comment_data()
# chronicpain_sub.save_comment_data()

# infertility_sub = CommentData(api, 'infertility')
# infertility_sub.retrieve_comments(limit=10000)
# infertility_sub.comments_to_dataframe()
# infertility_sub.clean_comment_data()
# infertility_sub.save_comment_data()

# trolling_sub = CommentData(api, 'trollingforababy')
# trolling_sub.retrieve_comments(limit=10000)
# trolling_sub.comments_to_dataframe()
# trolling_sub.clean_comment_data()
# trolling_sub.save_comment_data()

# PCOS_sub = CommentData(api, 'PCOS')
# PCOS_sub.retrieve_comments(limit=10000)
# PCOS_sub.comments_to_dataframe()
# PCOS_sub.clean_comment_data()
# PCOS_sub.save_comment_data()

# TTCPCOS_sub = CommentData(api, 'TTC_PCOS')
# TTCPCOS_sub.retrieve_comments(limit=10000)
# TTCPCOS_sub.comments_to_dataframe()
# TTCPCOS_sub.clean_comment_data()
# TTCPCOS_sub.save_comment_data()

# askwomen_sub = CommentData(api, 'AskWomen')
# askwomen_sub.retrieve_comments(limit=10000)
# askwomen_sub.comments_to_dataframe()
# askwomen_sub.clean_comment_data()
# askwomen_sub.save_comment_data()

# womenhealth_sub = CommentData(api, 'WomensHealth')
# womenhealth_sub.retrieve_comments(limit=10000)
# womenhealth_sub.comments_to_dataframe()
# womenhealth_sub.clean_comment_data()
# womenhealth_sub.save_comment_data()

# obgyn_sub = CommentData(api, 'obgyn')
# obgyn_sub.retrieve_comments(limit=10000)
# obgyn_sub.comments_to_dataframe()
# obgyn_sub.clean_comment_data()
# obgyn_sub.save_comment_data()
